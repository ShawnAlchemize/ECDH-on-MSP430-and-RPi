#include <msp430.h>
#include <time.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "driverlib/MSP430FR5xx_6xx/driverlib.h"
#include "myGpio.h"
#include "myClocks.h"
#include "myUart.h"
#include "stdio.h"
#include <math.h>


//***** Global Variables ******************************************************
//unsigned char gStr = 0x48;
uint8_t Message[] = {'h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', '1', '2', '3', '4', '5', '6'};
uint8_t Data[16];
uint8_t CipherKey[32];
/*
uint8_t CipherKey[32] =
    {'a', 'b', 'c', 'd',
    'e', 'f', 'g', 'h',
    'i', 'j', 'k', 'l',
    'm', 'n', 'o', 'p',
    'q', 'r', 's', 't',
    'u', 'v', 'w', 'x',
    'y', 'z', 'a', 'b',
    'c', 'd', 'e', 'f'};

*/

uint8_t DataAESencrypted[16];       // Encrypted data
uint8_t DataAESdecrypted[16];       // Decrypted data
unsigned int i;
unsigned int ii;
// The biggest 64bit prime
#define P 0xffffffffffffffc5ull
#define G 5
//OK initialization
char val[17];
char LEN[17];
int cc;
uint8_t lenData[16];
char OK[10] = {'1'};
char valdata[20];
int ival;
int someInt;
char somechar;
int someintarr[18];
//Calculation Initialization
time_t t;
static const uint64_t a = 2;
uint64_t A;
uint64_t number;
uint64_t B;
uint64_t secret1;
//Converting to ASCII Char for CipherKey
uint8_t result[8];
char chararray[8];
char str[32];
uint64_t num1;
uint8_t resultnum1[8];
char chararraynum1[8];
size_t len;
//Int2ASCII()
char secret1_integer_to_asciichar;
uint64_t digit2;
char secret1ascii_array[32];
int secretcount;
unsigned int count = 0;
//*****************************************************************************
    //DH key exchange function codes//


    uint64_t power(uint64_t a,uint64_t b,uint64_t mod)
        {
            uint64_t t;
            if(b==1)
            return a;
            t=power(a,b/2,mod);
            if(b%2==0)
                return (t*t)%mod;
            else
                return (((t*t)%mod)*a)%mod;
        }
    uint64_t calculateKey(uint64_t a,uint64_t x,uint64_t n)
    {
        return power(a,x,n);
    }
    uint64_t randomint64()
    {
        uint64_t a = rand();
        return a >> 8;
    }

//***** FUNCTIONS ************************************************************************

    //Watchdog, Clock init, Interrupt()
    void WCI(void)
    {
        // Disable the GPIO power-on default high-impedance mode to activate
        // previously configured port settings
        PM5CTL0 &= ~LOCKLPM5;

        WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer


        // Initialize GPIO
            initGPIO();

        // Initialize clocks
            initClocks();

        // Initialize UART (for backchannel communications)
        if ( myUart_init( BACKCHANNEL_UART, 9600, &myUart_Param_9600_8N1_SMCLK8MHz ) >> 0 )
            return;

        if ( myUart_init( CHANNEL_1, 9600, &myUart_Param_9600_8N1_SMCLK8MHz ) >> 0 )
            return;
    }

//******************************************************************************************************

    void LengthFromRPi(void)
    {

        int lencc;
        lencc = 4;
            if (LEN[0] == '0') //because of the extra in front, it becomes 0 first instead. remember val[i+1] previously?
            {cc = 10;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '1')
            {cc = 1;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '2')
            {cc = 2;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '3')
            {cc = 3;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '4')
            {cc = 4;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '5')
            {cc = 5;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '6')
            {cc = 6;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '7')
            {cc = 7;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '8')
            {cc = 8;printf("LEN[1]: %c\n", LEN[1]);}
            else if (LEN[1] == '9')
            {cc = 9;printf("LEN[1]: %c\n", LEN[1]);}
    }

//******************************************************************************************************

    void delayinterrupt(void)
    {
        __delay_cycles(10000000);
        __enable_interrupt();
    }

//******************************************************************************************************

    void UartOK(void)
    {
        unsigned int lensize = sizeof(OK);
               unsigned int lensizeMod16 = lensize%16;
               if(lensizeMod16!=0){
                   for (i=0;i<lensizeMod16;i++){
                       lenData[i]=OK[i];
                   }
                   for (i=0;i<16-lensizeMod16;i++){
                       lenData[lensizeMod16+i]=0x00;
                   }
               } else if(lensize == 16){
                   for (i=0;i<16;i++){
                       lenData[i]=OK[i];
                   }
               }
    }

//*****************************************************************************

    void UartSendVal()
    {
        myUart_readBuf( CHANNEL_1, (unsigned char *)val, 0);
    }

//*****************************************************************************

    void valprints(void)
    {
        printf("%.*s", cc, val);
        printf("\n");
        printf("%lls", val);
        printf("\n");
        //for(i=0;i<16;i++) printf("%x ",val[i]);
        //printf("\n");
        for(i=0;i<cc;i++) printf("%c ",val[i]);
        printf("\n");
        //for(i=0;i<16;i++) printf("%d ",val[i]);
        printf("\n");
        printf("\n");

        printf("DECRYPT DECRYPT DECRYPT\n");
    }

//*****************************************************************************

    void valvaldata(void)
    {
        //for (i=0;i<20;i++) valdata[i]= val[i+1];
        //due to the length of B check, no need for val[i+1]
        for (i=0;i<20;i++) valdata[i]= val[i];
    }

//*****************************************************************************

    void valdataprints(void)
    {
        for(i=0;i<cc;i++) printf("%c ",valdata[i]);
        printf("\n");

        for(i=0;i<cc;i++) printf("%d ",valdata[i]);
        printf("\n");
    }

//*****************************************************************************

    void char2int()
    {
        for(ival=0;ival<i;ival++)  //convert the char array into int array
        {
            somechar = valdata[ival];
            someInt = (somechar - '0');
            someintarr[ival] = someInt;
        }

        int it;
        uint64_t resultt = 0;
        for (it = 0; it < cc; it++)
        {
            resultt*=10;
            resultt+= someintarr[it];
        }
//             printf ("Result: %lld\n", resultt);
//             printf("\n");

             //received other device, "B", and do secretkey gen later
             B = resultt;
    }

//*****************************************************************************
    void DH1(void)
    {
        A = power(G, a, P);
        number = A;
    }

//*****************************************************************************

    void DH2ASCIIChararray(void)
    {
        //uint64_t to uint8_t codes
        uint8_t *p = (uint8_t *)&number;
        for (i=0;i<8;i++)
        {
            result[i] = p[i];
            chararray[i] = result[i];   //convert uint8 in result[i] to ascii in chararray[i]
         }
    }

//*****************************************************************************

    void DH2(void)
    {
        secret1 = power(B,a,P);
//        printf("secret1 = %lld\n", secret1);
    }

//*****************************************************************************

    void UartSendDH1()
    {
       unsigned int size = sizeof(result);
       unsigned int sizeMod16 = size%16;
       if(sizeMod16!=0){
           for (i=0;i<sizeMod16;i++){
               Data[i]=result[i];
           }
           for (i=0;i<16-sizeMod16;i++){
               Data[sizeMod16+i]=0x00;
           }
       } else if(size == 16){
           for (i=0;i<16;i++){
               Data[i]=result[i];
           }
       }
    }

//*****************************************************************************

    void UartSendData()
    {
        myUart_writeBuf( CHANNEL_1, (unsigned char *)Data, NULL, 0 );
    }

//*****************************************************************************

    void DisableInterruptsLowPowerMode4(void)
    {
//          printf("\n");
          // Disable all interrupts and enter Low Power Mode 4 (we could have replaced
          // this with a while(1); but that'd have taken more energy
          __disable_interrupt();
          __low_power_mode_4();
    }

//*****************************************************************************
    //DH key exchange codes//

    void DiffieHellman(void)
    {
        WCI();
        // Enable interrupts globally
        __enable_interrupt();

//        printf("START START START\n");
        srand((unsigned)time(&t));

    //***** UART LEN and OK ***************************************************************

        myUart_readBuf( CHANNEL_1, (unsigned char *)LEN, 0);

        LengthFromRPi();

        delayinterrupt();

        UartOK();

        myUart_writeBuf( CHANNEL_1, (unsigned char *)OK, NULL, 0 );

        printf("OK: %s\n", OK);

        delayinterrupt();


    //***** UART READ ***************************************************************

        UartSendVal();

        //valprints();

        valvaldata();

        //valdataprints();

        char2int();


    //***** CALCULATE BEFORE SEND ***************************************************************

        DH1();

        DH2ASCIIChararray();

    //***** SECRET CALCULATION ***************************************************************

        DH2();

    //***** UART SEND ***************************************************************

        delayinterrupt();

        UartSendDH1();

        UartSendData();

        //DisableInterruptsLowPowerMode4();
    }
//***** UART END ***************************************************************
//*****************************************************************************

    void reverse(char *x, int begin, int end)       //function to reverse the string in the same variable
    {
       char c;

       if (begin >= end)
          return;

       c          = *(x+begin);
       *(x+begin) = *(x+end);
       *(x+end)   = c;

       reverse(x, ++begin, --end);
    }

//*****************************************************************************

    void Int2ASCII()
    {
        secretcount = 0;
        memset(secret1ascii_array, 0, sizeof secret1ascii_array);
        while (secret1 > 0)
        {
            digit2 = secret1 % 100;
            //do something with 2digit
            //printf("digit= %lld\n", digit2);
            secret1_integer_to_asciichar = digit2 + 0;  //convert int to char
            //printf("secret1_integer_to_asciichar: %c\n", secret1_integer_to_asciichar);

            secret1ascii_array[secretcount] = secret1_integer_to_asciichar;   //store the ascii char in array
            secret1 /= 100;
            //printf("\n");
            secretcount++;
        }

        reverse(secret1ascii_array, 0, strlen(secret1ascii_array)-1);      //reverse the char string array, so that it will match the original integer order.
        printf("secret1ascii_array: %s\n", secret1ascii_array); //reversed to original order of the integer

        printf("secret1ascii_array: ");
        for (count=0;count<secretcount;count++) printf("%c ", secret1ascii_array[count]);
        printf("\n");
    }




//*****************************************************************************
    /*

    void Num12ASCIIChararray(void)
    {
        //uint64_t to uint8_t codes
        uint8_t *p = (uint8_t *)&num1;

        for (i=0;i<8;i++)
        {
            resultnum1[i] = p[i];
            chararraynum1[i] = resultnum1[i];   //convert uint8 in result[i] to ascii in chararray[i]
            printf("resultnum1[%d] = %d", i, resultnum1[i]);
            printf(" ");
            printf("chararraynum1[%d] = %llc\n", i, chararraynum1[i]);
        }
        printf("resultnum1: %s\n", resultnum1);
        printf("chararraynum1: %s\n", chararraynum1);
    }

    */
//*****************************************************************************

    void stringcopy(void)
    {
        strcpy(str, secret1ascii_array);
    }


//*****************************************************************************

    void stringlength(void)
    {
    len = strlen(str);
    printf ("Len(str): %d\n", len);
    }


//*****************************************************************************

    void stringadd(void)
    {
        strcat(str, secret1ascii_array);     //add the rest into str
    }

//*****************************************************************************

    void str2testarray32(void)
    {
    memset(CipherKey, 0, sizeof CipherKey); //empty the array first.
    for (i=0;i<32;i++) CipherKey[i]= str[i];
    for(i=0;i<32;i++) printf("%c ",CipherKey[i]);
    printf("\n");
    printf("CipherKey: %s\n", CipherKey);
    printf("\n");
    }

//*****************************************************************************



//*****************************************************************************



//*****************************************************************************

void main()
{
    printf("START START START\n");

    DiffieHellman();    //Algorithm for Diffiehellman. Final secret key is stored in variable, secret1.

    //***** AES BLEND ***************************************************************

    printf("CipherKey: %s\n", CipherKey);   //prints the default CipherKey[32].

    num1 = secret1 + 0;     //The following function codes uses the variable num1 which is the secret key from DH. (secret1 + 0 so that the num1 variable would not change secret1 variable)

    Int2ASCII();    //Convert the secret1 from Int to ASCII characters.

    // Num12ASCIIChararray();  //Convert from uint64 to uint8 and to ascii characters to store in the array for cipherkey

    stringcopy();       //copy the ascii characters to a temp array, str

    stringlength();     //check the length of str, it has to reach 32 characters.

    while(len < 32)     //while loop to repeat the process until str has more than 32 characters
    {
        printf("\nWHILE LOOP: \n");

        DiffieHellman();    //Repeat the same algorithm again to get another different secret1

        num1 = secret1 + 0;     //store the different 1 in num1 for the following codes

        Int2ASCII();

       // Num12ASCIIChararray();  ///Convert from uint64 to uint8 and to ascii characters to store in the array for cipherkey

        stringadd();        //add the ascii characters to the str array (not copy)

        stringlength();     //check the str length again to see if it is 32 or above.
    }

    printf("\n");
    printf("STR(ALL): %s\n", str);
    printf ("Len(str): %d\n", len);

    str2testarray32();      //replace the default cipher keys with the new cipher keys derived from DH and print




    //***** ENCRYPTION ***************************************************************


    delayinterrupt();

    char valuart[16];
    unsigned char valdatauart[17];

    // Read characters from the terminal
    myUart_readBuf( CHANNEL_1, (unsigned char *)valuart, 0);    //read and receive encrypted msg from RPi.

    for (i=0;i<16;i++) valdatauart[i]= valuart[i];              //Below is to decrypt and print out the encoded msg.
    // Load a cipher key to module
    AES256_setDecipherKey(AES256_BASE, CipherKey, AES256_KEYLENGTH_256BIT);
    // Decrypt data
    AES256_decryptData(AES256_BASE, (uint8_t*)valdatauart , DataAESdecrypted);
    printf("Valdatauart: \n");
    for(i=0;i<16;i++) printf("%x ",valdatauart[i]);
    printf("\n");
    printf("\n");
    printf("DataAESdecrypted(x): \n");
    for(i=0;i<16;i++) printf("%x ",DataAESdecrypted[i]);
    printf("\n");
    printf("DataAESdecrypted(c): \n");
    for(i=0;i<16;i++) printf("%c ",DataAESdecrypted[i]);
    printf("\n");
    printf("\n");


    __delay_cycles(10000000);   //*important* need an extra interupt to decrypt and print out RPi message.
    delayinterrupt();



    unsigned int size = sizeof(Message);
    unsigned int sizeMod16 = size%16;
    if(sizeMod16!=0){
        for (i=0;i<sizeMod16;i++){
            Data[i]=Message[i];
        }
        for (i=0;i<16-sizeMod16;i++){
            Data[sizeMod16+i]=0x00;
        }
    } else if(size == 16){
        for (i=0;i<16;i++){
            Data[i]=Message[i];
        }
    }


    // Load a cipher key to module
    AES256_setCipherKey(AES256_BASE, CipherKey, AES256_KEYLENGTH_256BIT);
    // Encrypt data with preloaded cipher key
    AES256_encryptData(AES256_BASE, Data, DataAESencrypted);

    //myUart_writeBuf( CHANNEL_1, (unsigned char *)variablenamecontainingthekey, NULL, 0);
    myUart_writeBuf( CHANNEL_1, (unsigned char *)DataAESencrypted, NULL, 0 );
    printf("Data: %s\n", Data);
    printf("DataAESencrypted(x): \n");
    for(i=0;i<16;i++) printf("%x ",DataAESencrypted[i]);
    printf("\n");
    printf("DataAESencrypted(c): \n");
    for(i=0;i<16;i++) printf("%c ",DataAESencrypted[i]);
    printf("\n");


    DisableInterruptsLowPowerMode4();

}
